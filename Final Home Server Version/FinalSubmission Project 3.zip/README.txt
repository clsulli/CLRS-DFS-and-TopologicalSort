TO RUN PROGRAM:

1.  Store project directory on home cs server somewhere.
2.  CD into project directory.
3.  Store graph text files in the "InputFiles" directory
4.  Do command "ls" and make sure you see "main.py", "LinkedList.py" and "Graph.py"
5.  After verifying you are in correct directory, do command "python main.py"
6.  Note when entering graph file location, just type filename, no need for the "InputFiles/" located before graph name.
7.  Follow program prompts until completion.
8.  Done.
